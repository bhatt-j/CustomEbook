<?php

include "config.php";

	

   	$u_name = $_POST["u_name"];
   	$b_name = $_POST["Book_name"];
	

    
	$select="DELETE FROM `bookmark_master` WHERE u_name = '$u_name' AND book_name ='$b_name'  ";
	
	$result=mysqli_query($conn,$select);

	if($result ) {
		echo "Remove Successfully";
	}
	else {
		echo "some error occured";
	}

?>