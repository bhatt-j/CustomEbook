<?php

$servername = "localhost";
$username = "id14223069_user";
$password = "Ebook@123456";
$dbname = "id14223069_ebook";

$conn = new mysqli($servername, $username, $password,$dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


	$name = $_POST["name"];
	$email =$_POST["email"];
	$phno =$_POST["phno"];
	$password =$_POST["password"];
	$id =$_POST["id"];
	
	

	$select = "UPDATE `register_master` SET `name`='$name',`email`='$email',`password`='$password',`contact`= '$phno' WHERE id = '$id' ";
	        
	
	$result = mysqli_query($conn,$select);
	
	if($result ) {
		echo "Update successfully";
	}
	else {
		echo "some error occured";
	}

?>