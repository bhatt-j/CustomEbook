<?php   

    echo "hello";

?>