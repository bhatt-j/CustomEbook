<?php

include "config.php";

	


	
	$return_arr = array();
	
	$select="SELECT * from `Author_master` ";
	
	$fetch=mysqli_query($conn,$select);

 

    while ($row = mysqli_fetch_array($fetch)) {
        $row_array['id'] = $row['0'];
        $row_array['name'] = $row['1'];
        $row_array['img'] = $row['2'];
      
        

    array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
?>