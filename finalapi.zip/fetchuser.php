<?php
include "config.php";



		$id = $_POST["id"];
	
		

		$sql = "SELECT * FROM `register_master`  WHERE  id = '$id'  ";
		$resul = mysqli_query($conn,$sql);
		
		
		  $result = array();
        $result['data'] = array();
		
		if($resul->num_rows > 0){
		      $row = mysqli_fetch_assoc($resul);
		      
		    $index['u_name'] = $row['name'];
            $index['u_mail'] = $row['email'];
            $index['u_password'] = $row['password'];
            $index['u_con'] = $row['contact'];
           
            
             array_push($result['data'], $index);
		      
			$result["success"] = "1";
			
			$result["message"] = "success";
			echo json_encode($result);
			mysqli_close($conn);
		
		
		}else{
			$result["success"] = "0";
			$result["message"] = "error";
	
			echo json_encode($result);
			mysqli_close($conn);
  			 echo "user not found or account is deactived";
    }
	


?>