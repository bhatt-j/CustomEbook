<?php

$servername = "localhost";
$username = "id14223069_user";
$password = "Ebook@123456";
$dbname = "id14223069_ebook";

$conn = new mysqli($servername, $username, $password,$dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


	$name = $_POST["u_name"];
	$email =$_POST["u_email"];
	$uid =$_POST["u_id"];
	$Bname =$_POST["Book_name"];
	$Bimg = $_POST["Book_img"];
	$Bookc =$_POST["Book_category"];
	$Burl =$_POST["Book_url"];
	$Bookdesc =$_POST["Book_desc"];
	$Totalpay =$_POST["Total_pay"];
		$Author =$_POST["Author"];
	
	

	$select = "INSERT INTO `order_master`(`book_name`, `book_url`, `book_img`, `book_desc`, `book_category`, `by_name`, `user_name`, `user_id`, `user_email`, `total_pay`) VALUES 
	('$Bname','$Burl','$Bimg','$Bookdesc','$Bookc','$Author','$name','$uid','$email','$Totalpay')";
	
	$result = mysqli_query($conn,$select);
	
	if($result ) {
	    
		      mail($email, "Your Order is SuccessFully!" , "Your Order is SuccessFully! \n Your Book Link \n ". $Burl ,"pateldarshak069@gmail.com");
		      echo "successfully mail send ";
		echo "Order Successfully";
	}
	else {
		echo "some error occured";
	}

?>