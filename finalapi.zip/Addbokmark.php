<?php

$servername = "localhost";
$username = "id14223069_user";
$password = "Ebook@123456";
$dbname = "id14223069_ebook";

$conn = new mysqli($servername, $username, $password,$dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


	$name = $_POST["u_name"];

	$Bname =$_POST["Book_name"];
	$Bimg = $_POST["Book_img"];
	$Bookc =$_POST["Book_category"];
	$Burl =$_POST["Book_url"];
	$Bookdesc =$_POST["Book_desc"];
	$Totalpay =$_POST["Price"];
	$cat2 =$_POST["Category2"];
	$Author =$_POST["Author"];
	$on = "on";
	

    $query = "SELECT * FROM `bookmark_master` WHERE book_name = '$Bname' AND u_name = '$name' ";
    $results = mysqli_query($conn, $query);
    $rows = mysqli_num_rows($results);
    
    if($rows === 0){
        
       	$select = "INSERT INTO `bookmark_master`(`book_name`, `book_img`, `book_rate`, `book_category`, `book_category2`, `by_name`, `book_desc`, `flag`, `book_url`, `u_name`)VALUES 
	('$Bname','$Bimg','$Totalpay','$Bookc','$cat2','$Author','$Bookdesc','$on','$Burl','$name')";
	
	$result = mysqli_query($conn,$select);
	
    	if($result ) {
    		echo "Added SuccessFull";
    	} 
    }else{
        echo "Already Added";
    }



// 	$select = "INSERT INTO `bookmark_master`(`book_name`, `book_img`, `book_rate`, `book_category`, `book_category2`, `by_name`, `book_desc`, `flag`, `book_url`, `u_name`)VALUES 
// 	('$Bname','$Bimg','$Totalpay','$Bookc','$cat2','$Author','$Bookdesc','$on','$Burl','$name')";
	
// 	$result = mysqli_query($conn,$select);
	
// 	if($result ) {
// 		echo "Added SuccessFull";
// 	}
	

?>