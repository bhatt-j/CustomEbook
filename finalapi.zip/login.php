<?php
include "config.php";

if(isset($_POST["email"])){

		$email = $_POST["email"];
		$password = $_POST["pass"];
		

		$sql = "SELECT * FROM `register_master`  WHERE  email = '$email' AND password = '$password'  ";
		$resul = mysqli_query($conn,$sql);
		
		
		  $result = array();
        $result['login'] = array();
		
		if($resul->num_rows > 0){
		      $row = mysqli_fetch_assoc($resul);
		      
		       $index['name'] = $row['name'];
            $index['email'] = $row['email'];
            $index['contact'] = $row['contact'];
            $index['id'] = $row['id'];
            
             array_push($result['login'], $index);
		      
			$result["success"] = "1";
			
			$result["message"] = "success";
			echo json_encode($result);
			mysqli_close($conn);
			echo "logged in successfully" ;
		
		}else{
			$result["success"] = "0";
			$result["message"] = "error";
	
			echo json_encode($result);
			mysqli_close($conn);
  			 echo "user not found or account is deactived";
    }
	
}
else{
	echo "error";
}


?>