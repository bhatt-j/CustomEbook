<?php

$servername = "localhost";
$username = "id14223069_user";
$password = "Password123&&&";
$dbname = "id14223069_ebook";



// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

if(isset($_POST["email"]))
{
	
    

		$email = $_POST["email"];
	

		$sql = "SELECT * FROM `register`  WHERE  `email` = '$email'";
		$resul = mysqli_query($conn,$sql);
		

		 $response = array();
        
		
		if(mysqli_num_rows($resul) > 0 ){
		    
		      $row = mysqli_fetch_assoc($resul);
		
		      
		      mail($row["email"], "Your Password is ".$row["password"], "Ebook","pateldarshak069@gmail.com");
		      echo "successfully mail send ";
		      
		       	mysqli_close($conn);
		}else{
	
			mysqli_close($conn);
  			 echo "email is not found plz check mail!!";
    }
}
else{
	echo "Error";
}

?>