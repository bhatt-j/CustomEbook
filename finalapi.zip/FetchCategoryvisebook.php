<?php

include "config.php";

	

   	$CAT_NAME = $_POST["cat_name"];
	

    $result=array();
	$result['data'] = array();
	$select="SELECT * FROM `readingbook_master` WHERE book_category = '$CAT_NAME' ";
	
	$responce=mysqli_query($conn,$select);

	while($row=mysqli_fetch_array($responce))
	{
		$index['id'] =$row['0'];
		$index['book_name']=$row['1'];
		$index['book_img']=$row['2'];

		array_push($result['data'], $index);
	}
	$result["success"]="1";
	echo json_encode($result);
	mysqli_close($conn);
?>