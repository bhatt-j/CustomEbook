
    <?php

include "config.php";

	

  	$UNAME = $_POST["u_name"];
	

    $result=array();
	$result['data'] = array();
	$select="SELECT * from `order_master` Where user_name = '$UNAME' ";
	
	$responce=mysqli_query($conn,$select);

	while($row=mysqli_fetch_array($responce))
	{
	 $index['id'] = $row['0'];
        $index['book_name'] = $row['1'];
        $index['book_url'] = $row['2'];
        $index['book_img'] = $row['3'];
        $index['book_desc'] = $row['4'];
        $index['book_category'] = $row['5'];
        $index['by_name'] = $row['6'];

		array_push($result['data'], $index);
	}
	$result["success"]="1";
	echo json_encode($result);
	mysqli_close($conn);
?>
?>