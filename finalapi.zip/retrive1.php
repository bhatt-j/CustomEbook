<?php

include "config.php";

	


	
	$return_arr = array();
	
	$select="SELECT * from `category_master` ";
	
	$fetch=mysqli_query($conn,$select);

 //   $fetch = mysqli_query($conn,"SELECT * FROM `category_master`"); 

    while ($row = mysqli_fetch_array($fetch)) {
        $row_array['id'] = $row['0'];
        $row_array['cat_name'] = $row['1'];
        

    array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
?>