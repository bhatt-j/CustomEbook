<?php


$servername = "localhost";
$username = "id14223069_user";
$password = "Ebook@123456";
$dbname = "id14223069_ebook";

$conn = new mysqli($servername, $username, $password,$dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>