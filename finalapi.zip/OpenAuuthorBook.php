<?php

include "config.php";

	

   	$A_NAME = $_POST["a_name"];
	

    $result=array();
	$result['data'] = array();
	$select="SELECT * FROM `readingbook_master` WHERE by_name = '$A_NAME' ";
	
	$responce=mysqli_query($conn,$select);

	while($row=mysqli_fetch_array($responce))
	{
		$index['id'] =$row['0'];
		$index['book_name']=$row['1'];
		$index['book_img']=$row['2'];
		$index['book_rate']=$row['3'];
		$index['book_category']=$row['4'];
		$index['book_category2']=$row['5'];
		$index['by_name']=$row['6'];
		$index['book_desc']=$row['7'];

		array_push($result['data'], $index);
	}
	$result["success"]="1";
	echo json_encode($result);
	mysqli_close($conn);
?>