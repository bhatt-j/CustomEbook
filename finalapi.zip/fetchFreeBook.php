<?php

include "config.php";

	


	
	$return_arr = array();
	
	$select="SELECT * from `readingbook_master` Where book_rate = '0' ";
	
	$fetch=mysqli_query($conn,$select);

 

    while ($row = mysqli_fetch_array($fetch)) {
        $row_array['id'] = $row['0'];
        $row_array['book_name'] = $row['1'];
        $row_array['book_img'] = $row['2'];
        $row_array['book_rate'] = $row['3'];
        $row_array['book_category'] = $row['4'];
        $row_array['book_category2'] = $row['5'];
        $row_array['by_name'] = $row['6'];
        

    array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
?>